"""Record ERA5 wind context for metadata-only southern IW acquisition selection."""
from __future__ import annotations
import json
from datetime import UTC, datetime
from pathlib import Path
import httpx
from cryolens.eval.cohort import file_digest

source = Path("data/processed/south-v4/january-2026-search.json")
output = Path("data/processed/south-v4/january-2026-wind-screen.json")
if output.exists():
    raise FileExistsError("Preserve meteorological receipt")
rows = json.loads(source.read_text())["candidates"]
params = {
    "latitude": ",".join(str(r["overlap_centroid"][1]) for r in rows),
    "longitude": ",".join(str(r["overlap_centroid"][0]) for r in rows),
    "start_date": "2026-01-01", "end_date": "2026-01-31",
    "hourly": "wind_speed_10m", "wind_speed_unit": "ms", "models": "era5",
    "cell_selection": "sea", "elevation": "nan", "timezone": "GMT",
}
payload = []
request_pages = []
for offset in range(0, len(rows), 20):
    batch = rows[offset:offset + 20]
    request = dict(params)
    request["elevation"] = ",".join("nan" for _ in batch)
    request["latitude"] = ",".join(str(round(r["overlap_centroid"][1], 5)) for r in batch)
    request["longitude"] = ",".join(str(round(r["overlap_centroid"][0], 5)) for r in batch)
    response = httpx.get("https://archive-api.open-meteo.com/v1/archive", params=request, timeout=180)
    if response.status_code != 200:
        failure = {"observed_at": datetime.now(UTC).isoformat(), "request_url": str(response.url), "status": response.status_code, "body": response.text}
        with Path(f"data/processed/south-v4/wind-api-failure-{offset}-{datetime.now(UTC).strftime('%H%M%S%f')}.json").open("x") as stream:
            json.dump(failure, stream, indent=2)
        response.raise_for_status()
    items = response.json()
    if isinstance(items, dict) and len(batch) == 1:
        items = [items]
    if not isinstance(items, list) or len(items) != len(batch):
        raise ValueError("Weather result cardinality does not match recorded coordinates")
    request_pages.append({"request_url": str(response.url), "response": items})
    payload.extend(items)
    print("Wind context fetched:", len(payload), "/", len(rows), flush=True)
ranked = []
for row, weather in zip(rows, payload, strict=True):
    if weather["hourly_units"]["wind_speed_10m"] != "m/s" or weather["utc_offset_seconds"] != 0:
        raise ValueError("Unexpected units or timezone")
    stamp = datetime.fromisoformat(row["date"].replace("Z", "+00:00"))
    nearest = min(range(len(weather["hourly"]["time"])), key=lambda i: abs((datetime.fromisoformat(weather["hourly"]["time"][i]).replace(tzinfo=UTC) - stamp).total_seconds()))
    value = weather["hourly"]["wind_speed_10m"][nearest]
    if value is None:
        continue
    ranked.append({"candidate": row, "wind_speed_10m_m_s": value,
        "weather_time_utc": weather["hourly"]["time"][nearest],
        "weather_grid_cell": [weather["longitude"], weather["latitude"]],
        "time_separation_minutes": abs((datetime.fromisoformat(weather["hourly"]["time"][nearest]).replace(tzinfo=UTC) - stamp).total_seconds()) / 60})
record = {"schema_version": 1, "observed_at": datetime.now(UTC).isoformat(),
    "purpose": "ERA5 metadata selection context, not observed wind, SAR truth or unbiased regional evaluation",
    "model": "ERA5 via Open-Meteo", "source_catalogue_sha256": file_digest(source),
    "driver_sha256": file_digest(Path(__file__)), "request_pages": request_pages,
    "response": payload, "screened": ranked,
    "selection_rule": "Rank January southern HH/HV IW candidates by nearest-hour ERA5 10m wind at catalogue overlap centroid; apply zero-height annotation and frozen-test exclusion guards, prefer distinct acquisitions and locations; no SAR pixels inspected."}
with output.open("x", encoding="utf-8") as stream:
    json.dump(record, stream, indent=2, allow_nan=False)
for item in sorted(ranked, key=lambda r: (-r["wind_speed_10m_m_s"], r["candidate"]["name"]))[:18]:
    row = item["candidate"]
    print(row["name"], item["wind_speed_10m_m_s"], "m/s", row["overlap_centroid"], flush=True)