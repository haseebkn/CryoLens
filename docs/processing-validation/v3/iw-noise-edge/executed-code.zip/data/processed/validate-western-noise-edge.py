import json,zipfile
from pathlib import Path
from cryolens.eval.cohort import file_digest
from cryolens.preprocess.safe_reader import SAFEProductReader,_open_path
from cryolens.preprocess.validation import run_reference,verify_reference_receipt,compare_window
root=Path('D:/CryoLens-data/sentinel1-step2-20261012')
n=json.loads(Path('data/processed/acquisition-plan-iw-western.json').read_text())['selected'][0]['name']
safe=Path(_open_path(root/'raw'/n.removesuffix('.SAFE')/n));scratch=Path('D:/CL12-snap-final')/n
out=root/'validation-iw-noise-edge';out.mkdir(exist_ok=False)
graph=Path('configs/snap/validation-reference-v2.xml');window=(18929,17204,213,8286)
config={'schema_version':2,'recipe_id':'iw-measured-zero-edge-20261012','purpose':'Additional short-block diagnostic only; not the fixed nine-window qualification and not a passing product.', 'frozen_manifest':'docs/evaluation/v1/manifest.json','graph':str(graph),'products':[{'name':'iw-noise-edge','path':str(safe)}],'diagnostic_window':list(window)}
configpath=Path('data/processed/validation-iw-noise-edge.json');configpath.write_text(json.dumps(config,indent=2))
modules={name:file_digest(Path('src/cryolens/preprocess')/name) for name in ['validation.py','quality.py','safe_reader.py','python_chain.py','marine_geocoding.py','stack.py']}
files=list(Path('src/cryolens').rglob('*.py'))+[Path(__file__).relative_to(Path.cwd()),graph,configpath]
with zipfile.ZipFile(out/'executed-code.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,f.as_posix())
(out/'source-sha256.json').write_text(json.dumps({f.as_posix():file_digest(f) for f in files},indent=2))
prefix=out/'reference'/'iw-noise-edge';run_reference(scratch,graph,prefix,window,'cryolens-snap-reference:14.0.0');verify_reference_receipt(scratch,graph,prefix,window,'cryolens-snap-reference:14.0.0')
w=compare_window(SAFEProductReader(safe),window,prefix,out/'diagnostics');w['reference_receipt_sha256']=file_digest(Path(str(prefix)+'-receipt.json'))
qualitypath=root/'quality-noise-edge-v2'/(n+'.json');q=json.loads(qualitypath.read_text());receipt=json.loads(Path(str(prefix)+'-receipt.json').read_text())
report={'schema_version':1,'configuration_sha256':file_digest(configpath),'graph_sha256':file_digest(graph),'reference_image':'cryolens-snap-reference:14.0.0','reference_image_id':receipt['image_id'],'validation_source_sha256':modules,'scientific_comparison_passed':w['scientific_comparison_passed'],'deployment_gate_open':False,'claim_boundary':config['purpose'],'products':[{'product':n,'mode':'IW','quality':q,'provenance':json.loads(Path('data/processed/western-reference-preparation.json').read_text()),'quality_report_sha256':file_digest(qualitypath),'windows':[w]}]}
(out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False));print(json.dumps({'scientific_comparison_passed':report['scientific_comparison_passed'],'checks':w.get('checks')}),flush=True)
